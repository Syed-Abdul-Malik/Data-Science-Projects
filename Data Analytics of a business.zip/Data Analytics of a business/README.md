#This is a personal project that shows the data analytics for the divali sales of an e commerce company.

Requirement to open this file: 
* python 
* jupyter 
* numpy
* pandas and pandas_profiling 
* matplotlib
* seaborn

Use " !pip install (name of the required extentions of this project) " in case this project doesn't work on your system.